<?php
// /wabo/logout.php

// 1. Iniciar con seguridad (necesario para poder destruir la sesi��n correcta)
require_once __DIR__ . '/../api/session_security.php';

// Destruir todas las variables de sesi��n.
$_SESSION = array();

// Borrar la cookie de sesi��n (Tu c��digo original, muy correcto).
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Finalmente, destruir la sesi��n.
session_destroy();

// Redirigir a la p��gina de login.
header("Location: login.php");
exit;
?>